﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafariPark
{
    public class Spartan
    {
        public string FirstName { get; init; }
        public string LastName { get; init; }

        public int Age { get; init; }

        //public Spartan(string fName, string lName, int age)
        //{
        //    Age = age;
        //    FirstName = fName;
        //    LastName = lName;
        //}

    }
}
