﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafariPark
{
    public class ShoppingList
    {
        public int Bread { get; set; }
        public int Milk { get; set; }
        public int Soap { get; set; }
        public int Potato { get; set; }
        public int Lemon { get; set; }

    }
}
